package com.company.companyData;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompanyDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
